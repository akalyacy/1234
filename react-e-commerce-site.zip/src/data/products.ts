export interface Product {
  id: number;
  title: string;
  price: number;
  category: string;
  inStock: boolean;
  image: string;
}

export const products: Product[] = [
  {
    id: 1,
    title: "Premium Laptop",
    price: 54999,
    category: "Electronics",
    inStock: true,
    image: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 2,
    title: "Cotton T-Shirt",
    price: 899,
    category: "Clothing",
    inStock: false,
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 3,
    title: "Hardcover Journal",
    price: 450,
    category: "Books",
    inStock: true,
    image: "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 4,
    title: "Wireless Headphones",
    price: 2499,
    category: "Electronics",
    inStock: true,
    image: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 5,
    title: "Running Shoes",
    price: 3200,
    category: "Clothing",
    inStock: false,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80"
  },
  {
    id: 6,
    title: "Sketchbook",
    price: 150,
    category: "Books",
    inStock: true,
    image: "https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80"
  }
];
