import React from 'react';
import { Product } from '../data/products';
import { motion } from 'motion/react';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const isExpensive = product.price > 1000;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -5 }}
      className="bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col h-full group"
    >
      <div className="relative aspect-square overflow-hidden bg-gray-100">
        <img
          src={product.image}
          alt={product.title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        {!product.inStock && (
          <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px] flex items-center justify-center">
            <span className="bg-red-500 text-white px-4 py-2 rounded-full font-bold text-sm shadow-lg">
              Sold Out ❌
            </span>
          </div>
        )}
        {isExpensive && product.inStock && (
          <div className="absolute top-3 left-3">
            <span className="bg-indigo-600 text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider shadow-md">
              Premium
            </span>
          </div>
        )}
      </div>

      <div className="p-5 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <span className="text-xs font-semibold text-indigo-600 uppercase tracking-wider">
            {product.category}
          </span>
        </div>
        
        <h3 className="text-lg font-bold text-gray-900 mb-2 line-clamp-1">
          {product.title}
        </h3>
        
        <div className="mt-auto flex items-center justify-between">
          <span className={`text-xl font-black ${isExpensive ? 'text-indigo-700' : 'text-gray-900'}`}>
            ${product.price.toLocaleString()}
          </span>
          
          {product.inStock ? (
            <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md">
              In Stock
            </span>
          ) : (
            <span className="text-xs font-medium text-red-600 bg-red-50 px-2 py-1 rounded-md">
              Unavailable
            </span>
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;
