import React from 'react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-white border-t border-gray-100 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="text-center md:text-left">
            <h2 className="text-xl font-bold text-gray-900">React E-Commerce</h2>
            <p className="text-sm text-gray-500 mt-1">Built with React, Tailwind, and Motion.</p>
          </div>
          
          <div className="flex gap-8 text-sm font-medium text-gray-600">
            <a href="#" className="hover:text-indigo-600 transition-colors">Privacy</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Terms</a>
            <a href="#" className="hover:text-indigo-600 transition-colors">Support</a>
          </div>
          
          <div className="text-sm text-gray-400">
            &copy; {currentYear} React E-Commerce Dashboard. All rights reserved.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
