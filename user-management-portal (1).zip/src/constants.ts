import { User } from './types';

export const MOCK_USERS: User[] = [
  { 
    id: 1, 
    name: 'John Doe', 
    email: 'john@example.com',
    bio: 'Software Engineer with a passion for building scalable web applications.',
    role: 'Senior Developer'
  },
  { 
    id: 2, 
    name: 'Jane Smith', 
    email: 'jane@example.com',
    bio: 'UX Designer focused on creating intuitive and accessible user experiences.',
    role: 'Lead Designer'
  },
  { 
    id: 3, 
    name: 'Robert Johnson', 
    email: 'robert@example.com',
    bio: 'Product Manager who loves bridging the gap between business and technology.',
    role: 'Product Owner'
  },
  { 
    id: 4, 
    name: 'Emily Davis', 
    email: 'emily@example.com',
    bio: 'Data Scientist exploring the intersection of AI and human behavior.',
    role: 'Data Analyst'
  },
];
