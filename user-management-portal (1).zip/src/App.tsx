import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import About from './pages/About';
import Users from './pages/Users';
import UserDetail from './pages/UserDetail';

export default function App() {
  return (
    <Router>
      <div className="min-h-screen bg-zinc-50 text-zinc-900 font-sans selection:bg-indigo-100 selection:text-indigo-900">
        <Navbar />
        <main className="pb-20">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/users" element={<Users />} />
            <Route path="/users/:id" element={<UserDetail />} />
          </Routes>
        </main>
        
        <footer className="border-t border-zinc-200 py-8 bg-white">
          <div className="max-w-7xl mx-auto px-4 text-center text-zinc-400 text-sm">
            &copy; {new Date().getFullYear()} User Management Portal. All rights reserved.
          </div>
        </footer>
      </div>
    </Router>
  );
}
