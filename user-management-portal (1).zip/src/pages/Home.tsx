import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowRight, Users, Info } from 'lucide-react';

export default function Home() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto py-12 px-4"
    >
      <div className="text-center space-y-6">
        <h1 className="text-5xl font-extrabold text-zinc-900 tracking-tight">
          Welcome to the <span className="text-indigo-600">User Management Portal</span>
        </h1>
        <p className="text-xl text-zinc-600 max-w-2xl mx-auto leading-relaxed">
          A streamlined platform designed to manage and explore user profiles with ease. Built with React, Tailwind CSS, and modern routing.
        </p>
        
        <div className="flex flex-col sm:flex-row justify-center gap-4 pt-8">
          <Link
            to="/users"
            className="flex items-center justify-center gap-2 bg-indigo-600 text-white px-8 py-4 rounded-xl font-semibold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200"
          >
            <Users size={20} />
            Explore Users
            <ArrowRight size={18} />
          </Link>
          <Link
            to="/about"
            className="flex items-center justify-center gap-2 bg-white text-zinc-700 border border-zinc-200 px-8 py-4 rounded-xl font-semibold hover:bg-zinc-50 transition-all"
          >
            <Info size={20} />
            Learn More
          </Link>
        </div>
      </div>

      <div className="mt-20 grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { title: 'Fast Routing', desc: 'Seamless navigation between pages using React Router.' },
          { title: 'Responsive', desc: 'Optimized for all devices from mobile to desktop.' },
          { title: 'Clean UI', desc: 'Modern aesthetic using Tailwind CSS utility classes.' },
        ].map((feature, i) => (
          <div key={i} className="p-6 bg-white rounded-2xl border border-zinc-100 shadow-sm">
            <h3 className="font-bold text-lg text-zinc-900 mb-2">{feature.title}</h3>
            <p className="text-zinc-500 text-sm leading-relaxed">{feature.desc}</p>
          </div>
        ))}
      </div>
    </motion.div>
  );
}
