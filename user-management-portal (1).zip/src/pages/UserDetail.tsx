import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { MOCK_USERS } from '../constants';
import { ArrowLeft, Mail, Briefcase, User as UserIcon, Calendar, MapPin } from 'lucide-react';

export default function UserDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const user = MOCK_USERS.find((u) => u.id === Number(id));

  if (!user) {
    return (
      <div className="max-w-2xl mx-auto py-20 px-4 text-center">
        <h2 className="text-2xl font-bold text-zinc-900 mb-4">User Not Found</h2>
        <p className="text-zinc-500 mb-8">The user you are looking for does not exist or has been removed.</p>
        <button
          onClick={() => navigate('/users')}
          className="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition-colors"
        >
          Back to Users List
        </button>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-3xl mx-auto py-12 px-4"
    >
      <div className="mb-6">
        <button
          onClick={() => navigate('/users')}
          className="flex items-center gap-2 text-zinc-500 hover:text-indigo-600 transition-colors font-medium"
        >
          <ArrowLeft size={18} />
          Back to Users List
        </button>
      </div>

      <div className="bg-white border border-zinc-200 rounded-3xl overflow-hidden shadow-sm">
        {/* Header/Banner */}
        <div className="h-32 bg-gradient-to-r from-indigo-500 to-purple-600"></div>
        
        <div className="px-8 pb-8">
          {/* Profile Picture Placeholder */}
          <div className="relative -mt-16 mb-6">
            <div className="w-32 h-32 bg-white rounded-2xl p-1 shadow-lg">
              <div className="w-full h-full bg-zinc-100 rounded-xl flex items-center justify-center text-zinc-400">
                <UserIcon size={64} />
              </div>
            </div>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
            <div>
              <h1 className="text-3xl font-bold text-zinc-900">{user.name}</h1>
              <p className="text-indigo-600 font-medium">{user.role || 'Professional'}</p>
            </div>
            <div className="flex gap-2">
              <button className="bg-indigo-600 text-white px-6 py-2 rounded-xl font-semibold hover:bg-indigo-700 transition-colors">
                Connect
              </button>
              <button className="border border-zinc-200 text-zinc-700 px-6 py-2 rounded-xl font-semibold hover:bg-zinc-50 transition-colors">
                Message
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-bold text-zinc-400 uppercase tracking-widest mb-3">About</h3>
                <p className="text-zinc-600 leading-relaxed">
                  {user.bio || 'No biography provided for this user.'}
                </p>
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-bold text-zinc-400 uppercase tracking-widest mb-3">Contact Information</h3>
                <div className="flex items-center gap-3 text-zinc-600">
                  <Mail size={18} className="text-zinc-400" />
                  <span>{user.email}</span>
                </div>
                <div className="flex items-center gap-3 text-zinc-600">
                  <MapPin size={18} className="text-zinc-400" />
                  <span>San Francisco, CA</span>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <h3 className="text-sm font-bold text-zinc-400 uppercase tracking-widest mb-3">Details</h3>
                <div className="bg-zinc-50 rounded-2xl p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-zinc-500">
                      <Briefcase size={16} />
                      <span className="text-sm">Department</span>
                    </div>
                    <span className="text-sm font-semibold text-zinc-900">Engineering</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-zinc-500">
                      <Calendar size={16} />
                      <span className="text-sm">Joined</span>
                    </div>
                    <span className="text-sm font-semibold text-zinc-900">Jan 2024</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-zinc-500">
                      <UserIcon size={16} />
                      <span className="text-sm">Status</span>
                    </div>
                    <span className="text-sm font-semibold text-emerald-600">Active</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
