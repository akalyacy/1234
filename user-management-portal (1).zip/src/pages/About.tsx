import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowLeft, Shield, Zap, Layout } from 'lucide-react';

export default function About() {
  return (
    <motion.div 
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      className="max-w-3xl mx-auto py-12 px-4"
    >
      <div className="space-y-8">
        <div className="flex items-center gap-4">
          <Link to="/" className="p-2 hover:bg-zinc-100 rounded-full transition-colors text-zinc-500">
            <ArrowLeft size={24} />
          </Link>
          <h1 className="text-3xl font-bold text-zinc-900">About This Application</h1>
        </div>

        <section className="bg-white p-8 rounded-3xl border border-zinc-200 shadow-sm space-y-6">
          <p className="text-lg text-zinc-600 leading-relaxed">
            This User Management Portal is a demonstration of a multi-page React application. It showcases core concepts of modern web development, including client-side routing, component reusability, and responsive design.
          </p>

          <div className="grid grid-cols-1 gap-6 pt-4">
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center">
                <Layout size={24} />
              </div>
              <div>
                <h3 className="font-bold text-zinc-900">Multi-Page Architecture</h3>
                <p className="text-zinc-500">Utilizes React Router for dynamic navigation without page reloads.</p>
              </div>
            </div>
            
            <div className="flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center">
                <Shield size={24} />
              </div>
              <div>
                <h3 className="font-bold text-zinc-900">Type Safety</h3>
                <p className="text-zinc-500">Built with TypeScript to ensure robust and maintainable code.</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-amber-100 text-amber-600 rounded-xl flex items-center justify-center">
                <Zap size={24} />
              </div>
              <div>
                <h3 className="font-bold text-zinc-900">Modern Styling</h3>
                <p className="text-zinc-500">Styled with Tailwind CSS for a utility-first, highly customizable UI.</p>
              </div>
            </div>
          </div>

          <div className="pt-6">
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-indigo-600 font-semibold hover:underline"
            >
              Back to Home Page
            </Link>
          </div>
        </section>
      </div>
    </motion.div>
  );
}
