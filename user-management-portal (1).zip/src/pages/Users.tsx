import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { MOCK_USERS } from '../constants';
import { User as UserIcon, ChevronRight, Mail } from 'lucide-react';

export default function Users() {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="max-w-5xl mx-auto py-12 px-4"
    >
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-zinc-900">User Directory</h1>
        <p className="text-zinc-500 mt-2">Manage and view detailed profiles of all registered users.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {MOCK_USERS.map((user) => (
          <Link 
            key={user.id} 
            to={`/users/${user.id}`}
            className="group block"
          >
            <div className="h-full bg-white border border-zinc-200 rounded-2xl p-6 transition-all hover:shadow-md hover:border-indigo-300 group-hover:-translate-y-1">
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-zinc-100 rounded-xl flex items-center justify-center text-zinc-400 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                  <UserIcon size={24} />
                </div>
                <ChevronRight size={20} className="text-zinc-300 group-hover:text-indigo-400 transition-colors" />
              </div>
              
              <h3 className="font-bold text-lg text-zinc-900 mb-1">{user.name}</h3>
              <div className="flex items-center gap-2 text-zinc-500 text-sm mb-4">
                <Mail size={14} />
                {user.email}
              </div>
              
              <div className="pt-4 border-t border-zinc-50">
                <span className="text-xs font-semibold uppercase tracking-wider text-indigo-600 bg-indigo-50 px-2 py-1 rounded">
                  {user.role || 'Member'}
                </span>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </motion.div>
  );
}
